# javascript_carousel
carousel using vanilla javascript

Includes two files with internal styles and JS
1) Automatic Carousel, changes slides for every 4 seconds
2) Manual Carousel, User needs to navigate with the help of prev and next buttons.
